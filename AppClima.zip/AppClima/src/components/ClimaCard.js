import React from 'react';

export default function ClimaCart (props) {

    return (
        <div className="col-12 col-md-4 col-lg-3 mt-3" >
            <div className="card" style={{width:"100%"}}>
                <div className="card-body">
                    <p className="card-text">{props.temperatura}</p>
                </div>
            </div>
        </div>
    );
}