import React,{useState,useEffect} from 'react';


export default function Home (props) {

    const [load,setLoad] = useState(true);
    const [txtCiudad, setTxtCiudad] = useState ("");
    const [txtCodigo, setTxtCodigo] = useState ("");
    const [data,setData] = useState(null);

    function getData () {
        const apiKey = `24311a5cc4430ddc7fd1d80426d60769`;
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${txtCiudad},${txtCodigo}&appid=${apiKey}`;
        console.log ("");
        console.log (url);
        console.log ("");
        setLoad(true);
        fetch(url,{method:"GET",mode: 'cors'})
        .then((data)=>{
            console.log(data);
            data.json().then((json)=>{
                setData(json);
                console.log(json);
                setLoad(false);
            });
        });

    }

    return (
        <div className = "container">

            <div className = "container">

            <div className = "container-fluid">

                <div className = "row">

                    <div className = "col-8">
                            <div className = "p-3 mb-2 bg-light text-white">

                                <div className="form-group">
                                    <label className = "text-dark">Ciudad</label>
                                    <input  type="text" 
                                            className="form-control" 
                                            id="exampleInputEmail1" 
                                            aria-describedby="emailHelp"
                                            onChange={(e)=>{setTxtCiudad(e.target.value)}} 
                                            value = {txtCiudad} />
                                </div>
                                <div className="form-group">
                                    <label className = "text-dark">Codigo Pais</label>
                                    <input  type="text" 
                                            className="form-control" 
                                            id="exampleInputPassword1"
                                            onChange={(e)=>{setTxtCodigo(e.target.value)}} 
                                            value = {txtCodigo} />
                                </div>
                                <button type="submit" 
                                        className="btn btn-primary"
                                        onClick={getData}>
                                    Consulta Clima
                                </button>

                            </div>

                    </div>


                    {
                        data && ( <div>
                        <div className="card" style={{width: "18rem"}}>
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item">Ubicacion: {txtCiudad}, {txtCodigo}</li>
                                <li className="list-group-item">Temperatura: {data.main.temp}</li>
                                <li className="list-group-item">Humedad: {data.main.humidity} </li>
                                <li className="list-group-item">Velocidad del viento: {data.wind.speed} </li>
                            </ul>
                        </div>
                    </div>
                    )}

                    </div>

            </div>

            <br/>


            </div>

        </div>
        

    );
}